package day8;

public class PeopleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		People p1 = new People();
		// p1.name = "홍길동"; - private 때문에 기본생성자로는 접근이 불가능하다 .
		p1.setName("홍길동");
		
		// System.out.println(p1.name); private 때문에 접근이 불가능하다 .
		System.out.println(p1.getName());
		
		People p2 = new People("이순신", 11);
		
		if(true) {
			System.out.println(p2.ageUp());
		}
		
	
	}

}
