package day8;

import java.util.Scanner;

public class UserMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		User[] list = new User[100];
		int cnt = 0;
		Util util = new Util();

		while (true) {
			System.out.println("==============회원가입==============");
			System.out.println("1.회원가입 2.로그인 3.리스트 4.검색 0.종료");
			System.out.print("메뉴선택> ");
			int menu = util.numberCheck1("메뉴");

			if (menu == 1) {
//				System.out.print("이름입력> ");
				String name = util.lengthCheck("이름", 4);
//				System.out.print("아이디입력> ");
				String id = util.lengthCheck("아이디", 6);
				System.out.print("비밀번호입력> ");
				String pw = sc.next();
				User user = new User(name, id, pw);
				list[cnt] = user;
				System.out.println("\n회원가입 완료!\n");
				cnt++;
			} else if (menu == 2) {
				System.out.print("로그인할 아이디입력> ");
				String loginId = sc.next();
				System.out.print("로그인할 비밀번호입력> ");
				String loginPw = sc.next();
//				boolean loginScc = false;

				for (int i = 0; i < cnt; i++) {
					if (loginId.equals(list[i].getId()) && loginPw.equals(list[i].getPw())) {
						System.out.println("\n로그인 성공");
//						loginScc = true;
						break;
					} else if (i == cnt - 1) {
						System.out.println("\n로그인 실패");
					}
//					if(!(loginScc)) {
//						System.out.println("\n아이디 또는 비밀번호를 다시 확인하세요.\n");
//					}
				}
			} else if (menu == 3) {
				System.out.println("이름\t아이디\t비밀번호");
				System.out.println("------------------------------");
				for (int i = 0; i < cnt; i++) {
					list[i].print();
//					System.out.printf("%s\t%s\t%s\n", list[i].getName(), list[i].getId(), list[i].getPw());
				}
			} else if (menu == 4) {
				System.out.print("검색할 아이디> ");
				String searchId = sc.next();
				System.out.println("이름\t아이디\t비밀번호");
				System.out.println("------------------------------");
//				for(String str : list)
				for (int i = 0; i < cnt; i++) {
					if (searchId.equals(list[i].getId())) {
						list[i].print();
						break;
					} else if (i == cnt - 1) {
						System.out.println("\n검색하신 아이디는 존재하지 않습니다.");
					}
				}
			} else if (menu == 0) {
				break;
			} else {
				System.out.println("다시 선택하세요.");
			}
			System.out.println();
		}
		System.out.println("\n프로그램 종료");

	}
}