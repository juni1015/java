package day8;

import java.util.Scanner;

public class Util {

// 숫자체크메소드 만들기
	public int numberCheck() {
		int result;
		Scanner sc = new Scanner(System.in);
		while (true) {
			if (sc.hasNextInt()) { // 만약 입력하려는 값이 숫자면
				result = sc.nextInt();// 값을 result에 넣고
				break; // 숫자가 잘입력되면 반복문을 빠져나옴
			} else
				System.out.print("숫자만 입력 > ");
			sc.nextLine();
		}
		return result;
	}

	public int numberCheck1(String str) {
		int result;
		Scanner sc = new Scanner(System.in);
		while (true) {
			if (sc.hasNextInt()) { // 만약 입력하려는 값이 숫자면
				result = sc.nextInt();// 값을 result에 넣고
				break; // 숫자가 잘입력되면 반복문을 빠져나옴
			} else
				System.out.print(str + "는 숫자만 입력 > "); // 다용도로 사용가능한 넘버체크 ( 내가원하는 문자를 삽입해서 사용가능 )
			sc.nextLine();
		}
		return result;
	}

// 아이디는 6자 이내 체크 함수 	

	public String lengthCheck(String str, int maxLength) {

		Scanner sc = new Scanner(System.in);
		System.out.print(str + "입력");
		String result;
		while (true) {
			result = sc.next();
			if (result.length() <= maxLength) {
				break;
			} else {
				System.out.println("최대 글자수는" + maxLength + "자 이내로 입력이 가능합니다");
				System.out.println("다시 입력하세요");
			}

		}
		return result;

	}
}

//  str의 길이를 측정하는법 
// string srt 
// str.length();
