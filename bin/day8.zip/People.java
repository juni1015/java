package day8;

public class People {

	private String name; // private 는 같은 클래스내에서만 허용이 가능하도록 접근제한
	private int age;

	public People() {

	}

	public People(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() { // getName는 Main으로 값을 리턴해줌
		return this.name;
	}

	public void setName(String name) { // setName는 Main에서부터 전달자 get과 set의 작동과정에대해 자세하게 복습
		this.name = name;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge() {
		this.age = age;
	}
	
	public int ageUp() {
		this.age++;
		return age;
	}

}
