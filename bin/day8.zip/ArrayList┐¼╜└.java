package day8;

import java.util.ArrayList;
import java.util.List;

public class ArrayList연습 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Member[] mList = new Member[10];

		Member m = new Member(); // 배열은 크기가 정해져있다
		mList[0] = m;
		mList[1] = m;
		mList[2] = m;
		for (int i = 0; i < mList.length; i++) {
			System.out.println(mList[i]);
		}

		List<Member> list = new ArrayList<>(); // Array리스트는 넣을수록 크기가 커진다.
		list.add(m);
		list.add(m);
		list.add(m);

		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}

		for (Member mm : list) { // 오른쪽에는 보통 배열이 들어가있고 왼쪽에는 그 값을 받는 변수가 있다
			System.out.println(mm);
		}
	}

}
