package day8;

//import java.util.ArrayList;
import java.util.*; // 자바 클래스에있는 모든것을 사용하겠다. 
//import java.util.Scanner;

public class MemberMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		Util util = new Util();
		List<Member> list = new ArrayList<>();
		int id = 0;

		while (true) {
			System.out.println("1.멤버등록 2.멤버리스트 3.검색 4.멤버수정 5.멤버삭제 0.종료");
			System.out.print("메뉴선택 > ");
			int menu = sc.nextInt();

			if (menu == 1) {
				Member member = new Member();
				member.setId(++id); // id++; 실행이 끝나고 id가 증감(후치증감) ++id 증감을 하고나서 실행을한다(전치증감)
				System.out.print("이메일입력 > ");
				member.setEmail(sc.next());
				System.out.print("비밀번호입력 > ");
				member.setPw(sc.next());
				System.out.print("이름입력 > ");
				member.setName(sc.next());
				list.add(member);
				System.out.println("멤버등록 완료!");

			} else if (menu == 2) {
				System.out.println("아이디\t 이메일\t 비밀번호\t 이름\t 가입일");
				System.out.println("-------------------------------------");
				for (Member m : list) { // 향샹된 for문 list의 값을 m에 옮겨 담으면서 반복한다.
					m.print();
				}

			} else if (menu == 3) {
				System.out.print("검색할 id > ");
				int searchId = sc.nextInt();
				boolean find = false;
				for (Member m : list) {
					if (m.getId() == searchId) {
						m.print();
						find = true;
						break;
					}
				}
				if (!find) {
					System.out.println("조회할 수 없는 id 입니다");
				}

			} else if (menu == 4) {
				System.out.println("수정할 id > ");
				int updateId = sc.nextInt();
				boolean find = false;
				for (Member m : list) {
					if (updateId == m.getId()) {
						System.out.print("이메일입력 > ");
						m.setEmail(sc.next());
						System.out.print("비밀번호입력 > ");
						m.setPw(sc.next());
						System.out.print("이름입력 > ");
						m.setName(sc.next());
						find = true;
						break;

					}
					if (!find) {
						System.out.println("조회할 수 없는 id 입니다");
					}
				}

			} else if (menu == 5) {
				System.out.println("살제할 id > ");
				int deleteId = sc.nextInt();
				boolean find = false;
				for (Member m : list) {
					if (deleteId == m.getId()) {
						System.out.println(m.getName() + "님 삭제완료");
						list.remove(m);
						break;
					}
				}
				if (!find) {
					System.out.println("조회할 수 없는 id 입니다");
				}

			} else if (menu == 0) {
				break;
			} else
				System.out.println("다시입력해주세요");
		}

		System.out.println("프로그램종료");

	}

}
